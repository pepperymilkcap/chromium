def SampleFunction():
  raise Exception('I should never be called!')
